<div class="page-heading">
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="page-title">
                    <h2>{{ $title ?? 'Page Title' }}</h2>
                </div>
            </div>
        </div>
    </div>
</div>