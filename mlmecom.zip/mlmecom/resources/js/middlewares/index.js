
export default class Middleware {
    constructor(middlewares){
        if(Array.isArray(middlewares)){

            middlewares.forEach((middleware) => {

            })
        }
    }


}