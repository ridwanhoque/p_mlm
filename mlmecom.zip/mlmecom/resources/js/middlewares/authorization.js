export default class Authorization {
    constructor(){

    }

    handle(){

    }
}