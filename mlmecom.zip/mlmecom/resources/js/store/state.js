export default {
    app: {
        isLoading: false
    },
    user: {}
}