<template>
    <div>
        <div class="app-title">
            <div>
                <h1><i class="fa fa-dashboard"></i> Dashboard</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="tile">
                    <div class="tile-body">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet aperiam asperiores consequuntur debitis delectus dolore, dolores, dolorum earum facilis inventore iste iusto laborum maiores, nihil nisi quae reprehenderit sed tempore.
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>