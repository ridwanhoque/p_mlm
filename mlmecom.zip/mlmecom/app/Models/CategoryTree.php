<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryTree extends Model
{
    //
}
